import {Text} from 'react-native'


const comp = (props) => {
  return <Text style = {{fontSize:50}}></Text>
}
export default comp