import React from  'react'
import {Text, View, StyleSheet} from 'react-native'
import styles from './src/style'

export default function App(){
  const tela = 
    <View style = {styles.view}>
      <Text style = {styles.texto}>12469</Text>
    </View>

  return ( 
   tela 
  )
}

